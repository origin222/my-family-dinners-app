// src/pages/PlannerView.jsx
import React from 'react';

export default function PlannerView() {
  return (
    <div style={{ padding: '1rem' }}>
      <h2>Planner</h2>
      <p>Welcome to your weekly planner. (Wire real content here.)</p>
    </div>
  );
}

// src/components/views/index.js

export * from './PlanningView';
export * from './ShoppingView';
export * from './ReviewView';
export * from './TimingView';
export * from './DetailView';
export * from './FavoritesView';
export * from './ShareView';
export * from './CookingView';
export * from './ArchivedPlansView'; // Add this line